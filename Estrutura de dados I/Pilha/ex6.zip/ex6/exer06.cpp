#include <iostream>
using namespace std;

#include "pilha-char.hpp"

#include <cctype>


int main(void)
{
    setlocale(LC_ALL, "Portuguese");

    Pilha p1;
    string palavra;
    char c;
    bool palindromo = true;

    //cout << "Informe uma string: ";
    //cin >> palavra;

    palavra = "socorram-me subi no onibus em marrocos.";

    inicializaP(&p1, palavra.size());


    for (int i=0; i<palavra.size(); i++)
    {
        c = palavra[i];
        if(isalpha(c))
        {
           empilhaP(&p1, c);
        }


    }

    mostraP(&p1);

    palindromo = true;
    for (int i=0; i<palavra.size(); i++)
    {
        if(isalpha(palavra[i]))
        {
           c = desempilhaP(&p1);
            if(c != palavra[i])
            {
                palindromo = false;
            }
        }

    }

    if(palindromo == true)
        cout << "A palavra " << palavra << " � um palindromo!\n";
    else
        cout << "A palavra " << palavra << " N�O � um palindromo!\n";


    destroiP(&p1);


    return EXIT_SUCCESS;

}//final do main

