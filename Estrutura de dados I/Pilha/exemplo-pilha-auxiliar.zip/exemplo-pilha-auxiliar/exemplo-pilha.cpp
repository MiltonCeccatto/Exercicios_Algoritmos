#include <iostream>
using namespace std;

#include "pilha.hpp"
#define TAM 10
int contP(Pilha* p)
{
    Pilha aux;
    inicializaP(&aux, TAM);

    int cont= 0;

    while(!vaziaP(p))
    {
        int dado = desempilhaP(p);
        empilhaP(&aux, dado);
        cont++;
    }

    while(!vaziaP(&aux))
    {
        int dado = desempilhaP(&aux);
        empilhaP(p, dado);
    }


    return cont;

}
int main(void)
{
    setlocale(LC_ALL, "Portuguese");

    int  valor;
    bool resultado;


    Pilha p1;
    inicializaP(&p1, TAM);

    empilhaP(&p1, 5);
    empilhaP(&p1, 7);
    empilhaP(&p1, 10);
    empilhaP(&p1, 20);
    empilhaP(&p1, 30);

    int cont = contP(&p1);
    cout << "Total de elementos da pilha: " << cont << endl;


    //desalocar mem�ria
    destroiP(&p1);


    return EXIT_SUCCESS;

}//final do main

