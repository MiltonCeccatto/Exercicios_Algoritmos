#include <iostream>
using namespace std;

#include "pilha-string.hpp"


int main(void)
{
    setlocale(LC_ALL, "Portuguese");

    Pilha p1;
    int opcaoMenu, tamPilha;
    string valor;

    do
    {
        system("cls");
        cout << "--------------MENU--------------" << endl;
        cout << "1: Criar\n";
        cout << "2: Inserir\n";
        cout << "3: Remover\n";
        cout << "4: Consultar\n";
        cout << "5: Mostrar\n";
        cout << "0: Sair\n";
        cout << "Escolha a op��o: ";
        cin >> opcaoMenu;

        if(opcaoMenu>1 && opcaoMenu<=5 && verificaInicializacaoP(&p1) == false )
            cout << "Erro: crie a pilha primeiro!\n";
        else if(opcaoMenu==1)
        {

            cout << "Informe o tamanho da pilha: ";
            cin >> tamPilha;
            if(tamPilha<=0)
                cout << "Informe um tamanho v�lido para a pilha (tam > 0)!\n";
            else
            {
                if(verificaInicializacaoP(&p1) == true)
                    destroiP(&p1);

                inicializaP(&p1, tamPilha);
            }


        }
        else if(opcaoMenu==2)
        {
            cout << "Informe o valor: ";
            cin >> valor;
            if(cheiaP(&p1) == false)
                if(buscaP(&p1, valor) == false)
                    empilhaP(&p1, valor);
                else
                    cout << "O valor " << valor << " n�o foi inserido. Valor duplicado!\n";
            else
                cout << "O valor " << valor << " n�o foi inserido. A pilha est� cheia!\n";
        }
        else if(opcaoMenu==3)
        {

            if( vaziaP(&p1) == false )
            {
                valor = desempilhaP(&p1);
                cout << "O valor " << valor << " foi desempilhado.\n";
            }
            else
                cout << "A pilha est� vazia!\n";
        }
        else if(opcaoMenu==4)
        {
            cout << "Informe o valor: ";
            cin >> valor;
            if(buscaP(&p1, valor) == true)
                cout << "O valor " << valor << " foi encontrado na pilha!\n";
            else
                cout << "O valor " << valor << " N�O foi encontrado na pilha!\n";
        }
        else if(opcaoMenu==5)
            mostraP(&p1);
        else if(opcaoMenu>4)
            cout << "Op��o inv�lida!\n\n";

        if(opcaoMenu>0)
            system("pause");

    }
    while(opcaoMenu !=0);


    destroiP(&p1);

    return EXIT_SUCCESS;

}//final do main

